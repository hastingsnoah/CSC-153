﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace HardCodeSales
{
    /**
* 01/27/2022
* CSC 153
* Hastings, Noah
* This program extracts data from a txt file and populates an array with the data. The data is used to display the contents of the array to the user in Gui
* The average, max number, and min number are then found and displayed to the user.
*/
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void getValues_Click(object sender, EventArgs e)
        {
            try
            {
                //Create an array to hold items read from the file
                const int SIZE = 7;
                decimal[] numbers = new decimal[SIZE];

                //Counter Variable to use in the loop
                int index = 0;

                //Declare  StreamReader variable.
                StreamReader inputFile;

                //open the file and get a streamreader object
                inputFile = File.OpenText("Sales.txt");

                //Read the file's contents into the array
                while (index < numbers.Length && !inputFile.EndOfStream)
                {
                    numbers[index] = decimal.Parse(inputFile.ReadLine());
                    index++;
                }

                //Close the file
                inputFile.Close();

                //Display the array elements in the list box.
                foreach (decimal value in numbers)
                {
                    outputListBox.Items.Add(value);
                }
                //Display Average of array values
                decimal avg = numbers.Average();
                string avgString = avg.ToString("G");
                avgBox.Items.Add(avgString);

                //Display largest array value
                largeBox.Items.Add(numbers.Max());
                //display smallest array value
                smallBox.Items.Add(numbers.Min());
            }
            catch (Exception ex)
            {
                //Display an Error Message
                MessageBox.Show(ex.Message);
            }
        }

        
    }
}
