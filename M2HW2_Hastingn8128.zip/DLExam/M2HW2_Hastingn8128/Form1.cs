﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW2_Hastingn8128
{
    
    public partial class DLQuiz : Form
    {
        String [] answers = new String [] {"B","D", "A" ,"A","C","A","B","A","C","D","B","C","D","A","D","C","C","B","D","A"};
        
        int questionNumber = 0;

        int correctAnswers = 0;
        public DLQuiz()
        {
            InitializeComponent();
            char[] answers = new char[20];
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void submit_Click(object sender, EventArgs e)
        {
                string answer =answers[questionNumber];
                
                string userAnswer = "n";
                //User input and data validation

                if (A.Checked) { userAnswer = "A"; }
                else if (B.Checked) { userAnswer = "B"; }
                else if (C.Checked) { userAnswer = "C"; }
                else if (D.Checked) { userAnswer = "D"; }

                //switch

                if (userAnswer == answer)
                {
                    correctLabel.Visible = true;
                    correctLabel.Text="Correct!";
                    correctAnswers++;
                }
                else
                {
                correctLabel.Visible = true;
                correctLabel.Text = "Incorrect.";
            }
                questionNumber++;
                numberLabel.Text = "Question #" + (questionNumber + 1) + ":";
                A.Checked = false;
                B.Checked = false;
                C.Checked = false;
                D.Checked = false;
            if (questionNumber == 20) 
            {
                numberLabel.Text = "You have completed the quiz.";
                if (correctAnswers<15) 
                {
                    resultsPanel.Visible = true;
                    results.Visible = true;
                    retryButton.Visible = true;
                    results.Text = "You have scored: " + correctAnswers + "/20\n" +
                        "You must score minimum 15/20 to pass.";
                }
                else
                {
                    resultsPanel.Visible = true;
                    results.Visible = true;
                    retryButton.Visible = true;
                    results.Text =  "You have scored: " + correctAnswers + "/20 \n" +
                        "You only needed 15/20 to pass.";
                }
                
            }
        }


        private void questionNum_TextChanged(object sender, EventArgs e)
        {

        }

        private void retryButton_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void resultsPanel_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
