﻿using System;
using System.IO;
namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            string name = "Thor";
            string Job = "Instructor";
            int age = 45;

            StreamWriter outputFile;

            try
            {
                outputFile = File.CreateText("test.txt");

                outputFile.WriteLine(name);
                outputFile.WriteLine(Job);
                outputFile.WriteLine(age);

                outputFile.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
