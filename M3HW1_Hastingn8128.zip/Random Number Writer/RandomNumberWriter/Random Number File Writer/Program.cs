﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Random_Number_File_Writer
{
    class Program
    {
        static void Main(string[] args)
        {
           
            // Get user input: How many random numbers the file will hold
            Console.WriteLine("How many numbers would you like to generate?");
            int userNum = int.Parse(Console.ReadLine());
            int loopCount = 0;
            
            StreamWriter outputFile;
            try
            {
                outputFile = File.CreateText("randomNumbers.txt");
                while (loopCount != userNum)
                {
                    //write Random number to user defined file
                    Random rand = new Random();
                    outputFile.WriteLine(rand.Next());
                    
                    loopCount++;
                }
                
                outputFile.Close();
            }
            //User a SaveFileDialog control to let user specify file name and location

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
